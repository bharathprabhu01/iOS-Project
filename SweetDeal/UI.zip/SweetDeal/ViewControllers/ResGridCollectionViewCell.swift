//
//  ResGridCollectionViewCell.swift
//  
//
//  Created by Sandy Pan on 11/23/19.
//

import UIKit

class ResGridCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var resNameLabel: UILabel!
  @IBOutlet weak var resPic: UIButton!

  
  
}
